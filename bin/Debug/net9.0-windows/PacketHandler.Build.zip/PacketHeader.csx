#r "nuget: System.Text.Json, 9.0.0"


using System;
using ProtoTestTool.ScriptContract;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;

[Flags]
public enum PacketFlags : byte
{
    None        = 0,
    HasError    = 1 << 0, // 0000 0001
    Compressed  = 1 << 1, // 0000 0010
    Encrypted   = 1 << 2, // 0000 0100
}


public static class PacketFlagsUtil
{
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static PacketFlags Add(PacketFlags current, PacketFlags flag)
        => current | flag;

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static PacketFlags Remove(PacketFlags current, PacketFlags flag)
        => current & ~flag;

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static bool Has(PacketFlags current, PacketFlags flag)
        => (current & flag) != 0;
}


public class Header : IHeader
{
    public Header()
    {
    }
    
    public Header(
        PacketFlags flags = PacketFlags.None,
        int msgId = 0,
        ushort msgSeq = 0,
        ushort errorCode = 0,
        int originalSize = 0)
    {
        Flags = flags;
        MsgId = msgId;
        MsgSeq = msgSeq;
        ErrorCode = errorCode;
        OriginalSize = originalSize;
    }

    public PacketFlags Flags;
    public int MsgId;
    public ushort MsgSeq;
    public ushort ErrorCode;
    public int OriginalSize;
    private const int FixedSize =
          sizeof(int)    // packet size
        + sizeof(byte)   // flags
        + sizeof(int)    // msgId
        + sizeof(ushort);// msgSeq

    public int GetSize()
    {
        return FixedSize
             + (HasError ? sizeof(ushort) : 0)
             + (IsCompressed ? sizeof(int) : 0);
    }
        
    public string ToJsonString()
    {
        return System.Text.Json.JsonSerializer.Serialize(this);
    }
        
    public bool HasError     => PacketFlagsUtil.Has(Flags, PacketFlags.HasError);
    public bool IsCompressed => PacketFlagsUtil.Has(Flags, PacketFlags.Compressed);
    public bool IsEncrypted  => PacketFlagsUtil.Has(Flags, PacketFlags.Encrypted);
}
